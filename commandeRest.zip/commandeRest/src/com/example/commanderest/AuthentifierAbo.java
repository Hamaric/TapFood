package com.example.commanderest;

import java.util.Random;

import com.example.model.BaseF;
import com.example.model.Client;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class AuthentifierAbo extends Activity{

	BaseF b;
	protected void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.authentifier_abo);

		Intent intent = getIntent();
		b = (BaseF)intent.getSerializableExtra("b");
	}


	public void authentifier(View sender){
		EditText edit_ident = (EditText) findViewById(R.id.authen_champ_identifiant);
		EditText edit_mdp = (EditText) findViewById(R.id.authen_champ_mdp);

		String ident = edit_ident.getText().toString();
		String mdp = edit_mdp.getText().toString();

		// pour signaler les erreurs, a mettre qd j'ai le temps
		//TextView text_auth = (TextView) findViewById(R.id.texte_rep_authen);

		for(int i=0; i<b.getAbonnes().size() ;i++){
			
			if(b.getAbonnes().get(i).getIdent().compareTo(ident)==0 &&
					b.getAbonnes().get(i).getMdp().compareTo(mdp)==0 &&
					b.getAbonnes().get(i).isEstAbonne()){
				
				b.getAbonnes().get(i).setEstAuthentifie(true);
			}
		}
		
		if(b.abonnesTousAuthentifies()){
			Intent intCMenu = new Intent(this, ChoixMenu.class);
			intCMenu.putExtra("b",b);
			startActivity(intCMenu);
		}
		else{
			Intent intContinueAuthen = new Intent(this, AuthentifierAbo.class);
			intContinueAuthen.putExtra("b",b);
			startActivity(intContinueAuthen);
		}


	}
}
