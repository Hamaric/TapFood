package com.example.commanderest;

import com.example.model.BaseF;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Carte extends Activity{
BaseF b;
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.carte);

		Intent intent = getIntent();
		b = (BaseF)intent.getSerializableExtra("b");
	}
	
	
	public void retourMenu(View sender){
		final Intent intMenuP = new Intent(this, MenuPrincipal.class);
		intMenuP.putExtra("b",b);
		startActivity(intMenuP);
	}
}
