package com.example.commanderest;

import java.util.ArrayList;
import java.util.HashMap;

import com.example.model.Article;
import com.example.model.BaseF;
import com.example.model.Client;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;


public class ChoixMenu extends Activity{

	BaseF b;
	
	public static ArrayList<Client> listClient;
	public static Client currentClient;
	public static HashMap<Integer, Article> articles;
	public static HashMap<Integer, TextView> quantities;

	
	@Override
	public void onCreate(Bundle savedInstances){
		super.onCreate(savedInstances);
		setContentView(R.layout.choix_menu);
		
		Intent intent = new Intent();
		b = (BaseF)intent.getSerializableExtra("b");
		
		articles = new HashMap<Integer, Article>();
		quantities = new HashMap<Integer, TextView>();
		afficherClient();
		createArticle();
		fillListeArticle();
	}
	

	public void afficherClient() {
		if (listClient != null && listClient.size() > 0) {
			setCurrentClient(listClient.get(0));
			
			for (Client cl : listClient) {
				final Client client = cl;
				LinearLayout.LayoutParams parms = new LinearLayout.LayoutParams(100, 100);
				try {
					GridLayout layout = (GridLayout) this.findViewById(R.id.listeClientsCommande);
					ImageView image = new ImageView(this);
					image.setImageResource(R.drawable.img_profil);
					image.setLayoutParams(parms);
					image.setPadding(10, 10, 10, 10);
					image.setOnClickListener(new OnClickListener() {
						
						
						@Override
						public void onClick(View v) {
							System.out.println("click");
							setCurrentClient(client);
							updateChoixMenuQuantity(client);
						}

					});

					layout.addView(image);
				} catch (Exception e) {
					e.printStackTrace();
				}

			}
		}
	}

	private void updateChoixMenuQuantity(Client client) {
		System.out.println("updateChoixMenuQuantity");
		System.out.println(client.getNom());
		HashMap<Integer, Integer> orderQuantities = client.getOrder().getOrderQuantities();

		if (orderQuantities.isEmpty()) {
			for (TextView quantity : quantities.values()) {
				quantity.setText("" + 0);
			}
		} else {
			
			for (TextView quantity : quantities.values()) {
				if(orderQuantities.get(quantity.getId()) != null){
					System.out.println(quantity.getId());
					quantities.get(quantity.getId()).setText("" + orderQuantities.get(quantity.getId()));
				}else{
					System.out.println("erroooor");
					quantity.setText("" + 0);
				}
			}
		
		}

	}

	protected void setCurrentClient(Client client) {
		currentClient = client;
		TextView textView = (TextView) findViewById(R.id.current_client_name);
		textView.setText(client.getNom() + " - Faites votre choix");
		// bordure
	}
	
	protected Client getCurrentClient() {
		return currentClient;
	}

	public void retourRenseignerPersonnes(View sender) {
		Intent intVersRetourRenseignerPersonnes = new Intent(this, RenseignerPersonnes.class);
		startActivity(intVersRetourRenseignerPersonnes);
	}

	public void envoyerCommande(View Sender) {
		Intent intVersCommandeEnvoye = new Intent(this, EnvoyerCommande.class);
		intVersCommandeEnvoye.putExtra("b",b);
		startActivity(intVersCommandeEnvoye);
	}

	public void voirCommande(View Sender) {
		Intent intVersCommandeEnvoye = new Intent(this, VoirCommande.class);
		startActivity(intVersCommandeEnvoye);
	}

	public void createArticle() {

		Article article;

		article = new Article(R.drawable.img_soupe, "Soupe Miso", 1.00f, 1);
		articles.put(1, article);

		article = new Article(R.drawable.img_nems, "Nems", 2.00f, 2);
		articles.put(2, article);

		article = new Article(R.drawable.img_sushi, "Sushi", 4.00f, 3);
		articles.put(3, article);

		article = new Article(R.drawable.img_maki, "Maki", 2.00f, 4);
		articles.put(4, article);

		article = new Article(R.drawable.img_brochettes, "Brochettes", 3.00f, 5);
		articles.put(5, article);

	}

	public void fillListeArticle() {
		GridLayout gridLayout = (GridLayout) this.findViewById(R.id.liste_articles);
		LinearLayout.LayoutParams parms = new LinearLayout.LayoutParams(100, 100);
		for (Article article : articles.values()) {
			ImageView image = new ImageView(this);
			image.setImageResource(article.getImage());
			image.setLayoutParams(parms);
			image.setPadding(10, 10, 10, 10);
			gridLayout.addView(image);

			TextView name = new TextView(this);
			name.setText(article.getName());
			name.setTextSize(25);
			name.setPadding(10, 10, 10, 10);
			gridLayout.addView(name);

			TextView price = new TextView(this);
			price.setText("" + article.getPrice() + "�");
			price.setTextSize(25);
			price.setPadding(10, 10, 10, 10);
			gridLayout.addView(price);

			// Remove article
			Button button = new Button(this);
			button.setText("-");
			button.setId(article.getId());
			button.setTextSize(35);
			button.setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View v) {
					int quantity = getCurrentClient().getOrder().removeArticle(v.getId(),articles.get(v.getId()).getPrice());

					quantities.get(v.getId()).setText("x "+ quantity);

				}
			});
			gridLayout.addView(button);

			TextView quantity = new TextView(this);
			quantity.setText("x 0");
			quantity.setTextSize(25);
			quantity.setPadding(10, 10, 10, 10);
			quantity.setId(article.getId());
			quantities.put(article.getId(), quantity);
			gridLayout.addView(quantity);

			// Add article
			button = new Button(this);
			button.setText("+");
			button.setId(article.getId());
			button.setTextSize(35);
			button.setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View v) {
					int quantity = getCurrentClient().getOrder().addArticle(v.getId(),articles.get(v.getId()).getPrice());

					quantities.get(v.getId()).setText("x " + quantity);

				}
			});
			gridLayout.addView(button);

		}

	}
	
	
}
