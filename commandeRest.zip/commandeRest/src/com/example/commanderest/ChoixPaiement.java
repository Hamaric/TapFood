package com.example.commanderest;

import java.util.ArrayList;
import java.util.List;

import com.example.model.BaseF;
import com.example.model.Client;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

public class ChoixPaiement extends Activity {

	private Client cQuiPaye;
	private BaseF b;
	private List<View> lView;
	private int indexCurrentClient;

	@Override
	public void onCreate(Bundle savedInstances) {
		super.onCreate(savedInstances);
		setContentView(R.layout.choix_paiement);

		Intent intent = getIntent();
		b = (BaseF) intent.getSerializableExtra("b");

		cQuiPaye = (Client) intent.getSerializableExtra("nomClient");

		lView = new ArrayList<View>();

		afficherClient();

	}

	public void afficherClient() {
		if (ChoixMenu.listClient != null && ChoixMenu.listClient.size() > 0) {

			int taille = 30;
			for (Client cl : ChoixMenu.listClient) {

				final Client client = cl;
				LinearLayout.LayoutParams parms = new LinearLayout.LayoutParams(100, 100);
				LinearLayout layoutCurrentClient = (LinearLayout) this.findViewById(R.id.clientQuiPaye);

				if (cQuiPaye.getIdClient() == client.getIdClient()) {
					
					for (int j = 0; j < ChoixMenu.listClient.size(); j++) {
						if(cQuiPaye.getIdClient() == ChoixMenu.listClient.get(j).getIdClient() ){
							ChoixMenu.listClient.get(j).setPrendEnCharge();
							indexCurrentClient = j;
						}
					}
					
					
					TextView name = new TextView(this);
					name.setText(cl.getNom());
					name.setTextColor(Color.parseColor("#000000"));
					name.setTextSize(taille);
					name.setPadding(10, 10, 10, 10);
					layoutCurrentClient.addView(name);

					TextView price = new TextView(this);
					price.setText("" + cl.getOrder().getPrixTotale() + "�");
					price.setTextColor(Color.parseColor("#000000"));
					price.setTextSize(taille);
					price.setPadding(10, 10, 10, 10);
					layoutCurrentClient.addView(price);

				} else {

					try {
						GridLayout layout = (GridLayout) this.findViewById(R.id.listeClientsAPaye);
						// checkbox pour choisir quel profil va payer

						if (client.getAUnPayeur() == false && client.getPrendEnCharge() == false) {
							TextView name = new TextView(this);
							name.setText(cl.getNom());
							name.setTextColor(Color.parseColor("#000000"));
							name.setTextSize(taille);
							name.setPadding(10, 10, 10, 10);
							layout.addView(name);

							TextView price = new TextView(this);
							price.setText("" + cl.getOrder().getPrixTotale() + "�");
							price.setTextColor(Color.parseColor("#000000"));
							price.setTextSize(taille);
							price.setPadding(10, 10, 10, 10);
							layout.addView(price);

							CheckBox checkBox = new CheckBox(this);
							checkBox.setId(client.getIdClient());
							lView.add(checkBox);
							layout.addView(checkBox);
						}

					} catch (Exception e) {
						e.printStackTrace();
					}
				}

			}
		}
	}

	public void addClient(View sender) {

		for (View view : lView) {
			CheckBox checkBox = (CheckBox) view.findViewById(view.getId());

			if (checkBox.isChecked()) {

				for (int i = 0; i < ChoixMenu.listClient.size(); i++) {
					if(ChoixMenu.listClient.get(i).getIdClient() == ChoixMenu.listClient.get(indexCurrentClient).getIdClient()){
					}
	
					else if (ChoixMenu.listClient.get(i).getIdClient() == view.getId()) {
						ChoixMenu.listClient.get(indexCurrentClient).addClientAPayer(ChoixMenu.listClient.get(i));
						ChoixMenu.listClient.get(i).setAUnPayeur();
						break;
					}
				}

			}

		}

		Intent intVersAttributionPaiement = new Intent(this, Paiement.class);
		intVersAttributionPaiement.putExtra("b", b);
		startActivity(intVersAttributionPaiement);

	}

}
