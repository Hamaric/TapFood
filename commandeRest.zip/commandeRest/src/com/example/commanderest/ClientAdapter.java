package com.example.commanderest;

import java.util.List;

import com.example.model.Client;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.TextView;

public class ClientAdapter extends ArrayAdapter<Client>{

	public ClientAdapter(Context context, List<Client> clients) {
		super(context, 0, clients);
	}
	
	@Override
    public View getView(int position, View convertView, ViewGroup parent) {
		if(convertView == null){
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.champ_rens_pers,parent, false);
        }
		
		ClientViewHolder viewHolder = (ClientViewHolder) convertView.getTag();
        if(viewHolder == null){
            viewHolder = new ClientViewHolder();
            //viewHolder.nom = (TextView) convertView.findViewById(R.id.nom_champ);
            viewHolder.abonne = (CheckBox) convertView.findViewById(R.id.coche_abonne);
            convertView.setTag(viewHolder);
        }
		
        Client client = getItem(position);
        
        //viewHolder.nom.setText(client.getNom());
		
		return convertView;
	}
	
	
	private class ClientViewHolder{
        public TextView nom;
        public TextView prenom;
        public CheckBox abonne;
    }

	
	
	
/*
	private List<Client> clients;
	private Context context;
	private LayoutInflater inflater;

	public ClientAdapter(Context cont, List<Client> aListP) {
		context = cont;
		clients = aListP;
		inflater = LayoutInflater.from(context);
	}
	@Override
	public int getCount() {
		return clients.size();
	}

	@Override
	public Object getItem(int position) {
		return clients.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}


	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		LinearLayout layoutItem;
		//(1) : R�utilisation des layouts
		if (convertView == null) {
			//Initialisation de notre item � partir du  layout XML "champ_rens_pers.xml"
			layoutItem = (LinearLayout) inflater.inflate(R.layout.champ_rens_pers, parent, false);
		} else {
			layoutItem = (LinearLayout) convertView;
		}

		//(2) : R�cup�ration des TextView de notre layout      
		EditText rens_edit_nom = (EditText)layoutItem.findViewById(R.id.rens_edit_nom);
		//TextView tv_Prenom = (TextView)layoutItem.findViewById(R.id.TV_Prenom);

		//(3) : Renseignement des valeurs       
		//rens_edit_nom.setText(clients.get(position).getNom());
		//tv_Prenom.setText(mListP.get(position).prenom);
		System.out.println("CHAMP renseigne "+position+" : "+clients.get(position).getNom()+" "+rens_edit_nom.getText().toString());
		//(4) Changement de la couleur du fond de notre item
		if (mListP.get(position).genre == Personne.MASCULIN) {
		    layoutItem.setBackgroundColor(Color.BLUE);
		  } else {
		  	layoutItem.setBackgroundColor(Color.MAGENTA);
		  }

		//On retourne l'item cr��.
		return layoutItem;
	}*/

}
