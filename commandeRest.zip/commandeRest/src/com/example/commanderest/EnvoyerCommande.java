package com.example.commanderest;

import com.example.model.BaseF;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class EnvoyerCommande  extends Activity{

	
	BaseF b;
	
	
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.envoyer_commande);
		Intent intent = new Intent();
		b = (BaseF)intent.getSerializableExtra("b");
		
	}
	
	public void payer(View sender){
		Intent intVersPayer = new Intent(this, Paiement.class);
		intVersPayer.putExtra("b",b);
		startActivity(intVersPayer);
		
	}
	
	public void retourCommande(View sender){
		Intent intVersRetourCommande = new Intent(this, ChoixMenu.class);
		intVersRetourCommande.putExtra("b",b);
		startActivity(intVersRetourCommande);
		
	}
	
	public void jouer(View sender){
		Intent intVersJouer = new Intent(this, Jouer.class);
		intVersJouer.putExtra("b",b);
		startActivity(intVersJouer);
		
	}
	
	
	
}
