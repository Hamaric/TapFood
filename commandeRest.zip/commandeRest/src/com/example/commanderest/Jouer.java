package com.example.commanderest;

import android.app.Activity;
import android.os.Bundle;

public class Jouer extends Activity{

	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		//setContentView(R.layout.jouer);
	}
}
