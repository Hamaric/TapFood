package com.example.commanderest;

import java.util.ArrayList;
import java.util.List;

import com.example.model.BaseF;
import com.example.model.Client;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;
import android.widget.ProgressBar;

public class MainActivity extends Activity {
	ImageView image;
BaseF b;
	// declaration du Handler
	/*Handler handler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			//bar.incrementProgressBy(5);
			//ImageView image = (ImageView)findViewById(R.id.imageView1);
			Animation animation1 = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.move);
			image.startAnimation(animation1);
		}
	};*/

	//boolean isRunning = false;

	/*public void onStart() {
		super.onStart();

		//bar.setProgress(0);
		// declaration du thread en arriere plan
		Thread background = new Thread(new Runnable() {
			public void run() {
				try {
					for (int i = 0; i < 20; i++) {
						// envoi du message (contenant le
						// bar.incrementProgressBy(5)
						handler.sendMessage(handler.obtainMessage());
						ImageView image = (ImageView)findViewById(R.id.imageView1);
						Animation animation1 = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.move);
						image.startAnimation(animation1);
					}
				} catch (Throwable t) {
				}
			}
		});
		isRunning = true;
		// lancement du thread
		background.start();
	}*/


	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		b = new BaseF();
	}

	public void onStart() {
		super.onStart();
		image = (ImageView)findViewById(R.id.imageView1);
		Animation animation1 = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.move);
		image.startAnimation(animation1);

	}

	public void commencer(View sender){
		final Intent intMenuPrincipal = new Intent(this, MenuPrincipal.class);

		intMenuPrincipal.putExtra("b",b);
		startActivity(intMenuPrincipal);
	}
/*
	public void mettreDonneesExtra(ArrayList<Client> clients, Intent intent){
		for(int i=0;i<clients.size();i++){
			//System.out.println("cl"+i+" : "+clients.get(i).getNom()+" "+clients.get(i).getPrenom());
			intent.putExtra("cl"+i,clients.get(i));
		}
		intent.putExtra("nbCl",clients.size());

	}*/
	
	
}
