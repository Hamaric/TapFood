package com.example.commanderest;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import com.example.model.BaseF;
import com.example.model.Client;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;

public class MenuPrincipal extends Activity {

	BaseF b;
	
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_menu_principal);
		
		Intent intent = getIntent();
		b = (BaseF)intent.getSerializableExtra("b");
		/*int sizeClients = intent.getIntExtra("nbCl", 0);
		System.out.println("nbClients : "+sizeClients);
		
		List<Client> clients = new ArrayList<Client>();
		Client client;
		for(int i=0; i<sizeClients ;i++){
			client = (Client)intent.getSerializableExtra("cl"+i);
			clients.add(client);
			System.out.println("cl"+i+" : "+clients.get(i).getNom()+" "+clients.get(i).getPrenom());
		}
		System.out.println("SIZE  : "+clients.size());*/
		
	}

	public void renseigneSolo(View sender){
		renseigner(sender, 1);
		b.genererSolo();
	}
	public void renseigneCouple(View sender){
		renseigner(sender, 2);
		b.genererCouple();
	}
	public void renseigneGroupe(View sender){
		renseigner(sender, 3);
		b.genenerGroupe();
	}
	public void renseigner(View sender, int nbClients){
		final Intent intRenseignerPersonnes = new Intent(this, RenseignerPersonnes.class);
		intRenseignerPersonnes.putExtra("b", b);
		intRenseignerPersonnes.putExtra("nbCl",nbClients);
		startActivity(intRenseignerPersonnes);
	}

	public void afficherCarte(View sender){
		final Intent intCarte = new Intent(this, Carte.class);
		intCarte.putExtra("b", b);
		startActivity(intCarte);
	}

	public void reservation(View sender){
		final Intent intResa = new Intent(this, Reservation.class);
		intResa.putExtra("b", b);
		startActivity(intResa);
	}

	public void changeFr(View sender){
		setLocale("fr");
	}
	public void changeEn(View sender){
		setLocale("en");
	}
	public void changeEs(View sender){
		setLocale("es");
	}
	public void changeJa(View sender){
		setLocale("ja");
	}
	public void changeIt(View sender){
		setLocale("it");
	}

	Locale myLocale;
	
	public void setLocale(String lang) { 
		myLocale = new Locale(lang); 
		Resources res = getResources(); 
		DisplayMetrics dm = res.getDisplayMetrics(); 
		Configuration conf = res.getConfiguration(); 
		conf.locale = myLocale; 
		res.updateConfiguration(conf, dm); 
		Intent refresh = new Intent(this, MenuPrincipal.class); 
		startActivity(refresh); 
		finish();
	}
	/*
	// puis essayer avec le finish avant l'intent
	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
		Intent refresh = new Intent(this, MenuPrincipal.class); 
		startActivity(refresh); 
		finish();
	}
*/
}
