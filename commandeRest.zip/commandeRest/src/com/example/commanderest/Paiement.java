package com.example.commanderest;

import com.example.model.BaseF;
import com.example.model.Client;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.style.TypefaceSpan;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

public class Paiement extends Activity {

	public static Client currentClient;
	BaseF b;

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.paiement);

		Intent intent = getIntent();
		b = (BaseF) intent.getSerializableExtra("b");

		afficherClient();
	}

	public void aurevoir(View sender) {
		Intent intVersAcc = new Intent(this, MainActivity.class);
		intVersAcc.putExtra("b", b);
		startActivity(intVersAcc);
	}

	public void afficherClient() {
		if (ChoixMenu.listClient != null && ChoixMenu.listClient.size() > 0) {
			setCurrentClient(ChoixMenu.listClient.get(0));
			int id = 1;
			int taille = 30;
			for (Client cl : ChoixMenu.listClient) {

				final Client client = cl;
				try {

					GridLayout layout = (GridLayout) this.findViewById(R.id.listeClientsPaiement);


					if (client.getAUnPayeur() == false && client.getPrendEnCharge() == false) {

						TextView name = new TextView(this);
						name.setText(cl.getNom());
						name.setTextColor(Color.parseColor("#000000"));
						name.setTextSize(taille);
						name.setPadding(10, 10, 10, 10);
						layout.addView(name);

						TextView price = new TextView(this);
						price.setText("" + cl.getOrder().getPrixTotale() + "�");
						price.setTextColor(Color.parseColor("#000000"));
						price.setTextSize(taille);
						price.setPadding(10, 10, 10, 10);
						layout.addView(price);

						CheckBox checkBoxCB = new CheckBox(this);
						layout.addView(checkBoxCB);

						TextView textCB = new TextView(this);
						textCB.setText("CB");
						textCB.setTextColor(Color.parseColor("#000000"));
						textCB.setTextSize(taille);
						textCB.setPadding(10, 10, 10, 10);
						layout.addView(textCB);

						CheckBox checkBoxEspece = new CheckBox(this);
						layout.addView(checkBoxEspece);

						TextView textEspece = new TextView(this);
						textEspece.setText("Espece");
						textEspece.setTextColor(Color.parseColor("#000000"));
						textEspece.setTextSize(taille);
						textEspece.setPadding(10, 10, 10, 10);
						layout.addView(textEspece);

						
						
						Button buttonPayerPour = new Button(this);
						buttonPayerPour.setId(id);
						buttonPayerPour.setText("payerPour");
						layout.addView(buttonPayerPour);
						id++;
						buttonPayerPour.setOnClickListener(new OnClickListener() {

							@Override
							public void onClick(View v) {

								System.out.println(client.getNom());
								attributionPaiement(v, client);

							}
						});
					} else if (client.getPrendEnCharge() == true) {

						TextView name = new TextView(this);
						name.setText(cl.getNom());
						name.setTextColor(Color.parseColor("#000000"));
						name.setTextSize(taille);
						name.setPadding(10, 10, 10, 10);
						layout.addView(name);

						TextView price = new TextView(this);
						price.setText("" + cl.getOrder().getPrixTotale() + "�");
						price.setTextColor(Color.parseColor("#000000"));
						price.setTextSize(taille);
						price.setPadding(10, 10, 10, 10);
						layout.addView(price);

						CheckBox checkBoxCB = new CheckBox(this);
						layout.addView(checkBoxCB);

						TextView textCB = new TextView(this);
						textCB.setText("CB");
						textCB.setTextColor(Color.parseColor("#000000"));
						textCB.setTextSize(taille);
						textCB.setPadding(10, 10, 10, 10);
						layout.addView(textCB);

						CheckBox checkBoxEspece = new CheckBox(this);
						layout.addView(checkBoxEspece);

						TextView textEspece = new TextView(this);
						textEspece.setText("Espece");
						textEspece.setTextColor(Color.parseColor("#000000"));
						textEspece.setTextSize(taille);
						textEspece.setPadding(10, 10, 10, 10);
						layout.addView(textEspece);

						Button buttonModifier = new Button(this);
						buttonModifier.setId(id);
						buttonModifier.setText("Modifier");
						layout.addView(buttonModifier);
						id++;
						buttonModifier.setOnClickListener(new OnClickListener() {

							@Override
							public void onClick(View v) {

								System.out.println(client.getNom());
								attributionPaiement(v, client);

							}
						});

					} else {
						TextView name = new TextView(this);
						name.setText(cl.getNom());
						name.setTextColor(Color.parseColor("#000000"));
						name.setTextSize(taille);
						name.setPadding(10, 10, 10, 10);
						layout.addView(name);

						TextView price = new TextView(this);
						price.setText("" + cl.getOrder().getPrixTotale() + "�");
						price.setTextColor(Color.parseColor("#000000"));
						price.setTextSize(taille);
						price.setPadding(10, 10, 10, 10);
						layout.addView(price);

						TextView payePar = new TextView(this);
						payePar.setText("Payer");
						payePar.setTextColor(Color.parseColor("#000000"));
						payePar.setTextSize(taille);
						payePar.setPadding(10, 10, 10, 10);
						layout.addView(payePar);

						TextView text1 = new TextView(this);
						text1.setText(" ");
						layout.addView(text1);

						TextView text2 = new TextView(this);
						text2.setText(" ");
						layout.addView(text2);

						TextView text3 = new TextView(this);
						text3.setText(" ");
						layout.addView(text3);

						TextView text4 = new TextView(this);
						text4.setText(" ");
						layout.addView(text4);
					}

				} catch (Exception e) {
					e.printStackTrace();
				}

			}
		}
	}

	protected void setCurrentClient(Client client) {
		currentClient = client;

		// bordure
	}

	public void attributionPaiement(View sender, Client client) {

		System.out.println(client.getNom());
		Intent intVersAttributionPaiement = new Intent(this, ChoixPaiement.class);
		intVersAttributionPaiement.putExtra("nomClient", client);
		intVersAttributionPaiement.putExtra("b", b);
		startActivity(intVersAttributionPaiement);
	}

}
