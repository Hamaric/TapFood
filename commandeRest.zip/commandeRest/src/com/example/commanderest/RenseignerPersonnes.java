package com.example.commanderest;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.example.model.BaseF;
import com.example.model.Client;

import android.app.Activity;
import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;
import android.widget.EditText;

public class RenseignerPersonnes extends Activity {

	List<Client> clients = new ArrayList<Client>();
	BaseF b;
	List<View> lView;
	LinearLayout view;
	int nbCl;

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		Intent intent = getIntent();
		b = (BaseF) intent.getSerializableExtra("b");
		nbCl = (int) intent.getIntExtra("nbCl", 1);
		lView = new ArrayList<View>();

		if (nbCl == 1) {
			setContentView(R.layout.renseigner_personnes_solo);
			View v = LayoutInflater.from(this).inflate(R.layout.champ_rens_pers, null);
			lView.add(v);
		} else if (nbCl == 2) {
			setContentView(R.layout.renseigner_personnes_couple);
		} else {
			setContentView(R.layout.renseigner_personnes_groupe);
			Button bt_ajout = (Button) findViewById(R.id.ajout_entree);
			view = (LinearLayout) findViewById(R.id.myView);

			for (Client c : b.getClientsTMP())
				clients.add(c);
		}
	}

	public void ajouterEntree(View sender) {
		View v = LayoutInflater.from(this).inflate(R.layout.champ_rens_pers, null);
		v.findViewById(R.id.retrait_entree).setTag(v.findViewById(R.id.retrait_entree).toString());
		// v.setTag(v.toString());
		lView.add(v);
		view.addView(v);
		// clients.add(new Client("jil","pika"));
	}

	public void retirerEntree(View sender) {
		// Client c2 = clients.remove(1);
		View tmp = null;
		Button b = (Button) sender;
		// View v = (View) sender.getParent();
		// Log.d("RETIRE_ENTREE", v.toString());
		// System.out.println("RETIRE_ENTREE : " + sender.toString() + " tag: "
		// + v.getTag());

		for (View view : lView) {
			Button bTmp = (Button) view.findViewById(R.id.retrait_entree);
			System.out.println("bTmp == null " + (bTmp == null));
			if (bTmp.getTag().equals(b.getTag())) {
				tmp = view;
				break;
			}
		}
		System.out.println("Size avant : " + lView.size());

		view.removeView(tmp);
		lView.remove(tmp);
		System.out.println("Size apres : " + lView.size());
	}

	public void choisirMenu(View sender) {

		System.out.println("etat 1 *********************");
		for (View v : lView) {
			EditText editText = (EditText) v.findViewById(R.id.rens_edit_nom);
			CheckBox checkBox = (CheckBox) v.findViewById(R.id.coche_abonne);

			if (checkBox.isChecked()) {
				b.getClientsTMP().add(new Client("", editText.getText().toString(), true));
			} else {
				b.getClientsTMP().add(new Client("", editText.getText().toString(), false));
			}
		}

		for (Client c : b.getClientsTMP()) {
			System.out.println("nom " + c.getNom() + " prenom " + c.getPrenom() + " abo ? " + c.isEstAbonne());
		}

		System.out.println("etat 2 *********************");
		ChoixMenu.listClient = new ArrayList<Client>();
		for (Client c : b.getClientsTMP()) {
			ChoixMenu.listClient.add(c);
		}

		System.out.println("etat 3 *********************");

		if (b.nbAbonnes(b.getAbonnes()) == 0) {
			Intent intVersChoixMenu = new Intent(this, ChoixMenu.class);
			intVersChoixMenu.putExtra("b", b);
			startActivity(intVersChoixMenu);
			System.out.println("etat 4 *********************");
		} else {
			Intent intVersAuthentification = new Intent(this, AuthentifierAbo.class);
			intVersAuthentification.putExtra("b", b);
			startActivity(intVersAuthentification);
			System.out.println("etat 5 *********************");
		}

	}

}
