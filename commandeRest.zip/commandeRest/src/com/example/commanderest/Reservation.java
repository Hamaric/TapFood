package com.example.commanderest;

import java.util.ArrayList;
import java.util.List;

import com.example.model.BaseF;
import com.example.model.Client;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Reservation extends Activity {
	BaseF b;

	protected void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_reservation);
		Intent intent = getIntent();
		b = (BaseF)intent.getSerializableExtra("b");
	}


	public void chercherResa(View sender){
		EditText edit_nom = (EditText) findViewById(R.id.resa_nom);
		EditText edit_prenom = (EditText) findViewById(R.id.resa_prenom);

		String nom = edit_nom.getText().toString();
		String prenom = edit_prenom.getText().toString();

		TextView text_resa = (TextView) findViewById(R.id.texte_rep_resa);

		boolean trouve=false;
		Client tmp=null;
		for(Client c : b.getReservations()){
			//System.out.println("chercehr ===================== 4");
			if(c.getNom().compareTo(nom)==0 && c.getPrenom().compareTo(prenom)==0 && c.getNumResa()!=-1){
				//System.out.println("Bienvenue"+c.getNom()+" "+c.getPrenom()+", Veuillez vous rendre � la table"+c.getNumResa());
				//text_resa.setText("Bienvenue "+c.getNom()+" "+c.getPrenom()+", Veuillez vous rendre � la table"+c.getNumResa());
				
			    // Execute some code after 2 seconds have passed
			    /*Handler handler = new Handler(); 
			    handler.postDelayed(new Runnable() { 
			         public void run() {  
			         } 
			    }, 6000); 
				*/
				//Intent intMain = new Intent(this, MainActivity.class);
				//startActivity(intMain);
				//finish();
				trouve=true;
				tmp=c;
				break;
			}
			else{
				//System.out.println("chercehr ===================== 5");
				//text_resa.setText("Aucune reservation trouvee !");
				//System.out.println("chercehr ===================== 6");
			}
		}
		if(trouve){
			text_resa.setText("Bienvenue "+tmp.getNom()+" "+tmp.getPrenom()+", Veuillez vous rendre � la table"+tmp.getNumResa());
			//System.out.println("chercehr === TROUVE ==== 5");
		}
		else{
			//System.out.println("chercehr =========NONO============ 5");
			text_resa.setText("Aucune reservation trouvee !");
			//System.out.println("chercehr ====== NONO============ 6");
		}

	}

	public void retourMenu(View sender){
		final Intent intMenuP = new Intent(this, MenuPrincipal.class);
		intMenuP.putExtra("b",b);
		startActivity(intMenuP);
	}
	
}
