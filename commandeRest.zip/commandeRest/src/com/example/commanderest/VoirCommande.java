package com.example.commanderest;

import com.example.model.Article;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class VoirCommande extends Activity {

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.voir_commande);
		int taille = 30;
		GridLayout gridLayout = (GridLayout) this.findViewById(R.id.liste_articles_commande);
		gridLayout.removeAllViews();
		
		LinearLayout.LayoutParams parms = new LinearLayout.LayoutParams(100, 100);
		float sommeTotale = 0;
		for (Integer idArticle : ChoixMenu.currentClient.getOrder().getOrderQuantities().keySet()) {
			Article article = ChoixMenu.articles.get(idArticle);

			TextView name = new TextView(this);
			name.setText(article.getName());
			name.setTextSize(taille);
			name.setPadding(10, 10, 10, 10);
			name.setTextColor(Color.parseColor("#000000"));
			gridLayout.addView(name);

			ImageView image = new ImageView(this);
			image.setImageResource(article.getImage());
			image.setLayoutParams(parms);
			image.setPadding(10, 10, 10, 10);
			gridLayout.addView(image);

			int qte = ChoixMenu.currentClient.getOrder().getOrderQuantities().get(article.getId());
			TextView quantite = new TextView(this);
			quantite.setText("x " + qte);
			quantite.setTextSize(taille);
			quantite.setPadding(10, 10, 10, 10);
			quantite.setTextColor(Color.parseColor("#000000"));
			gridLayout.addView(quantite);

			float somme = qte * article.getPrice();
			TextView price = new TextView(this);
			price.setText("" + somme + "�");
			price.setTextSize(taille);
			price.setPadding(10, 10, 10, 10);
			price.setTextColor(Color.parseColor("#000000"));
			gridLayout.addView(price);

			sommeTotale += somme;
		}
		TextView sommeTotaleView = (TextView) this.findViewById(R.id.somme_total);
		sommeTotaleView.setText("Total : " + sommeTotale + " �");
		sommeTotaleView.setTextSize(50);
		sommeTotaleView.setPadding(10, 10, 10, 10);
		sommeTotaleView.setTextColor(Color.parseColor("#000000"));

	}

}
