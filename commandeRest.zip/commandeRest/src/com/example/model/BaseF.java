package com.example.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class BaseF implements Serializable {

	ArrayList<Client> abonnes = new ArrayList<Client>();
	
	ArrayList<Client> clientsTMP = new ArrayList<Client>();
	ArrayList<Client> reservations = new ArrayList<Client>();
	
	public BaseF() {
		/// base de donnee fictive abones
		//abonnes.add(new Client("marc","leroux",true,"maki","m12"));
		//abonnes.add(new Client("rachid","kader",true,"coucou","salut30"));
		//abonnes.add(new Client("nathalie","florent",true,"natou4","bien"));
		
		reservations.add(new Client("pierre","go",3));
		reservations.add(new Client("marie","thibault",-1));
		
	}

	public boolean abonnesTousAuthentifies() {
		for(Client c : abonnes){
			if(!c.estAuthentifie) return false;
		}
		return true;
	}
	
	public int nbAbonnes(List<Client> clients){
		int cpt=0;
		for(Client c : clients){
			if(c.estAbonne) cpt++;
		}
		return cpt;
	}

	///// clients tmp
	public void genererSolo() {
		clientsTMP.add(new Client("marc","leroux"));
	}
	public void genererCouple() {
		clientsTMP.add(new Client("marc","leroux"));
		clientsTMP.add(new Client("jeannes","David"));
	}
	public void genenerGroupe() {
		clientsTMP.add(new Client("marc","leroux"));
		clientsTMP.add(new Client("jeannes","David"));
		clientsTMP.add(new Client("rachid","kader"));
		clientsTMP.add(new Client("yann","lee"));
		clientsTMP.add(new Client("aboubakar","diarra"));
	}
	
	public ArrayList<Client> getAbonnes() {
		return abonnes;
	}
	public ArrayList<Client> getClientsTMP() {
		return clientsTMP;
	}
	public void setAbonnes(ArrayList<Client> abonnes) {
		this.abonnes = abonnes;
	}
	public void setClientsTMP(ArrayList<Client> clientsTMP) {
		this.clientsTMP = clientsTMP;
	}
	public ArrayList<Client> getReservations() {
		return reservations;
	}
	public void setReservations(ArrayList<Client> reservations) {
		this.reservations = reservations;
	}

}
