package com.example.model;

import java.io.Serializable;
import java.util.ArrayList;

public class Client implements Serializable{

	String nom, prenom;
	
	boolean estAbonne;
	String ident, mdp;
	
	private Order order;
	
	String nomImage;
	int numResa; /// aucune resa = -1 /// a reserve >= 0
	boolean estAuthentifie; // s'il est abonne et s'il s'est bien connecte => true
	private int idClient;
	private static int cpt = 1;
	
	private ArrayList<Client> clientAPayer;
	
	private boolean aUnPayeur = false;
	
	private boolean prendEnCharge = false;

	public Client() {
		this.order = new Order();
		clientAPayer = new ArrayList<Client>();
		idClient = cpt;
		cpt++;
		clientAPayer.add(this);
	}
	public Client(String prenom, String nom ) {
		this.order = new Order();
		clientAPayer = new ArrayList<Client>();
		idClient = cpt;
		cpt++;
		this.nom = nom;
		this.prenom = prenom;
		clientAPayer.add(this);
	}
	public Client( String prenom, String nom, int resa) {
		this.order = new Order();
		clientAPayer = new ArrayList<Client>();
		idClient = cpt;
		cpt++;
		this.nom = nom;
		this.prenom = prenom;
		this.numResa = resa;
		clientAPayer.add(this);
	}
	public Client( String prenom, String nom, boolean abo, String ident, String mdp) {
		this.order = new Order();
		clientAPayer = new ArrayList<Client>();
		idClient = cpt;
		cpt++;
		this.nom = nom;
		this.prenom = prenom;
		this.estAbonne = abo;
		this.ident = ident;
		this.mdp = mdp;
		clientAPayer.add(this);
	}
	public Client( String prenom, String nom, boolean abo) {
		this.order = new Order();
		clientAPayer = new ArrayList<Client>();
		idClient = cpt;
		cpt++;
		this.nom = nom;
		this.prenom = prenom;
		this.estAbonne = abo;
		clientAPayer.add(this);
	}



	public Order getOrder(){
		return this.order;
	}
	
	public void setOrder(Order order){
		this.order = order;
	}
	public String getIdent() {
		return ident;
	}
	public String getMdp() {
		return mdp;
	}
	public void setIdent(String ident) {
		this.ident = ident;
	}
	public void setMdp(String mdp) {
		this.mdp = mdp;
	}
	public boolean isEstAbonne() {
		return estAbonne;
	}
	public int getNumResa() {
		return numResa;
	}
	public boolean isEstAuthentifie() {
		return estAuthentifie;
	}
	public void setEstAbonne(boolean estAbonne) {
		this.estAbonne = estAbonne;
	}
	public void setNumResa(int numResa) {
		this.numResa = numResa;
	}
	public void setEstAuthentifie(boolean estAuthentifie) {
		this.estAuthentifie = estAuthentifie;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getPrenom() {
		return prenom;
	}
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	public String getNomImage() {
		return nomImage;
	}
	public void setNomImage(String nomImage) {
		this.nomImage = nomImage;
	}

	public ArrayList<Client> getClientAPayer(){
		return clientAPayer;
	}
	
	public void addClientAPayer(Client client){
		clientAPayer.add(client);
	}
	public void removeClientAPayer(Client client){
		clientAPayer.remove(client);
	}
	
	public int getIdClient(){
		return idClient;
	}
	
	public boolean getAUnPayeur(){
		return aUnPayeur;
	}
	
	public void setAUnPayeur(){
		aUnPayeur = true;
	}
	
	public boolean getPrendEnCharge(){
		return prendEnCharge;
	}
	
	public void setPrendEnCharge(){
		prendEnCharge = true;
	}

}
