package com.example.model;

import java.io.Serializable;
import java.util.HashMap;

public class Order implements Serializable{
	
	private HashMap<Integer, Integer> orderQuantities;
	private float sommeTotale = 0;

	public Order() {
		orderQuantities = new HashMap<Integer, Integer>();
	}

	public int addArticle(int id,float price) {
		int quantity = 1;
		if (orderQuantities.get(id) != null) {
			quantity = orderQuantities.get(id) + 1;
			
		}
		orderQuantities.put(id, quantity );
		sommeTotale += price;
		return quantity;
	}

	public int removeArticle(int id,float price) {
		int quantity = 0;
		if (orderQuantities.get(id) != null) {
			quantity = orderQuantities.get(id) - 1;
		}
		if (quantity == 0) {
			orderQuantities.remove(id);
		} else {
			orderQuantities.put(id, quantity );
		}
		sommeTotale -= price;

		return quantity;
//		int quantity = 0;
//		if (orderQuantities.get(id) != null && orderQuantities.get(id) != 0) {
//			quantity = orderQuantities.get(id) - 1;
//		}
//		return quantity;
	}

	public HashMap<Integer, Integer> getOrderQuantities() {
		return orderQuantities;
	}
	
	public float getPrixTotale(){
		return sommeTotale;
	}

}
